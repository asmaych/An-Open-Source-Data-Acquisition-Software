#include "sensor/Sensor.h"

//Constructor
Sensor::Sensor(const std::string& name, int pin)
{
	/* \brief This class takes a name and an integer "pin" 
	 * as parameters.
	 *
	 * the pin represents the arduino/esp32 pin that will
	 * be used to read sensor values.
	 *
	 * the name represents what the sensor will be called
	 * and displayed to the user as.
	 *
	 * Both name and pin must be unique, but that will be
	 * enforced in an owning class SensorManager object.
	 */
	m_name = name;
	m_pin = pin;
	m_rawreading = 0;	//initialize to zero on creation
	m_mappedreading = 0;	//initialize to zero on creation
	m_voltage = 0;		//initialize to zero on creation
}

// get/return sensor name
std::string Sensor::getName() const
{
	return m_name;
}

// get sensor ID
int Sensor::getPin() const
{
	return m_pin;
}

// get current raw reading (before calibration)
int Sensor::getRawReading() const
{
	return m_rawreading.load(); 
	/* load is a thread safe read operation that retrieves 
	 * a value from shared memory without interruption. 
	 * It guarantees that the entire value is read as a 
	 * single, complete unit, preventing other threads from 
	 * seeing a corrupted value during read process.
	*/
}
float Sensor::getVoltage() const
{
	return m_voltage.load();
}

//get current mapped value (calibrated values)
int Sensor::getMappedReading() const
{
	return m_mappedreading.load();
}

// set new reading
void Sensor::setReading(int value)
{
	//store the raw reading
	m_rawreading.store(value);  
	/* store is an atomic operation that writes a value to a 
	 * memory location as a single, indivisible action, ensuring 
	 * that it's either fully completed or not at all. (i am using 
	 * atomic (thread-safe) again to guarantee that other processes
	 * will never see a partially updated value. 
	*/

	//TODO: implement the calibration function (in-line or object)
	m_mappedreading.store(value);

	/* Note that the esp32 converts a range of voltage from
	 * 0 - 3.3 V --> 0 - 4096 for the analog-to-digital conversion.
	 * Sometimes, we may want to know the actual voltage that the
	 * sensor outputs, and for this, we run the inverse of the ADC
	 * function: 0 - 4096 --> 0 - 3.3 V
	 */
	m_voltage.store(0.0008056640625*value);



}
