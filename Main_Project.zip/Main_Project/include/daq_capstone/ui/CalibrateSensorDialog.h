#pragma once

#include <wx/wx.h>
#include "SensorManager.h"
#include "Sensor.h"
#include "string"

class CalibrateSensorDialog : public wxDialog
{
	public: 
		CalibrateSensorDialog(
					wxWindow* parent,
					const wxString& title,
					SensorManager* sensorManager,
					const wxString& sensor_name); 

	private:
		//------------------------------------------------------
		//CLASS MEMBERS
		//------------------------------------------------------

		//this is passed through the constructor as a raw pointer
		//to SensorManager class instance that originates in 
		//ProjectPanel. This is used to handle the calibration in
		//each sensor.
		SensorManager* m_sensorManager;

		//this is passed through the constructor as a reference
		//to the name of the sensor that is beig calibrated. It
		//will be used to specify a sensor to m_sensorManager
		//when the calibration specifications are set
		wxString m_sensor_name;

		//------------------------------------------------------
		//EVENT HANDLERS
		//------------------------------------------------------

		//for when the "Manual Table" button is pressed
		void onManualTablePressed(wxCommandEvent& evt);

		//for when the "Equation" button is pressed
		void onEquationPressed(wxCommandEvent& evt);

		//for when the "Datasheet graph" button is pressed
		void onDatasheetPressed(wxCommandEvent& evt);


};

